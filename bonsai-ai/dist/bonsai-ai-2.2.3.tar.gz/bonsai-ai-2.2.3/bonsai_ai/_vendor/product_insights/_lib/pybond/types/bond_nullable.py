from pybond.types import BondList


class BondNullable(BondList):
    pass
