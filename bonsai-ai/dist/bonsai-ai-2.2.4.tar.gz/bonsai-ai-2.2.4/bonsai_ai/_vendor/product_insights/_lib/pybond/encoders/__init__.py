from pybond.encoders import compact_binary
