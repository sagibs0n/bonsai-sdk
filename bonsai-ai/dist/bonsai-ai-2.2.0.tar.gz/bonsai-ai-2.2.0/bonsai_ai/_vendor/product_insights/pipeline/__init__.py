from __future__ import absolute_import

from product_insights.pipeline.event_pipeline import EventPipeline

__all__ = ['EventPipeline']
