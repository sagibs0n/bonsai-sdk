from pybond.types import BondList


class BondVector(BondList):
    pass
