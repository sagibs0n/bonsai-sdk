class ClientMessageType(object):
    ClientEvent = 1
    ClientAggregate = 2