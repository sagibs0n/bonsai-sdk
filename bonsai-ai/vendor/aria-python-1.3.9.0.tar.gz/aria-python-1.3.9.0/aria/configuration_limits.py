class ConfiguationLimits(object):
    MAX_TCP_CONNECTION_ALLOWED = 6
    MIN_TCP_CONNECTION_ALLOWED = 1