from distutils.core import setup

setup(name='aria-python',
      version='1.3.9.0',
      description='Aria telemetry client',
      author='Ionescu Marius Robert',
      author_email='roionesc@microsoft.com',
      packages=['aria']
     )